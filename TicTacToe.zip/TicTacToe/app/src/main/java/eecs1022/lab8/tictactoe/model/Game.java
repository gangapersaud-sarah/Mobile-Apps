package eecs1022.lab8.tictactoe.model;

public class Game {

    private String Player1 ;
    private String Player2;
    private String whosPlayingNow;
    private char [][] Board;
    private String Status;
    private String Starter;

    public Game(String player1, String player2) {
        this.Player1 = player1;
        this.Player2 = player2;
        this.whosPlayingNow = player1;
        this.Starter = player1;
        this.Status = getCurrentPlayer() + "'s turn to play...";
        char[] topRow = {'_', '_', '_'};
        char[] middleRow = {'_', '_', '_'};
        char[] bottomRow = {'_', '_', '_'};
        this.Board = new char[][]{topRow, middleRow, bottomRow};

    }

    boolean checkForTie(){
        for(int r = 0; r < this.getBoard().length; r++){
            for(int c = 0; c < this.getBoard()[r].length; c++){
                if(this.getBoard()[r][c]=='_'){
                    return false;
                }
            }
        }
        return true;
    }

    public String getPlayer1() {
        return this.Player1;
    }
    public String getPlayer2() {
        return this.Player2;
    }
    public String getCurrentPlayer() {
        return this.whosPlayingNow;
    }
    public String getStatus() {
        return this.Status;
    }
    public char[][] getBoard() {
        return this.Board;
    }
    public void setWhoPlaysFirst(char xo) {
        if(xo == 'o') {
            this.Player2 = getPlayer2();
            this.whosPlayingNow = this.Player2;

            this.Starter = this.Player2;
        }
        else {
            this.Player1 = getPlayer1();
            this.whosPlayingNow = this.Player1;

            this.Starter = this.Player1;
        }
        //this.whosPlayingNow = this.Player2;
        this.Status = whosPlayingNow + "'s turn to play...";
    }

    public void move(int row, int col) {
        if (row <= 0 || row > 3){
            this.Status = "Error: row " + row + " is invalid.";
        }
        else if (col <= 0 || col > 3){
            this.Status = "Error: col " + col + " is invalid.";
        }
        else {
            int r = 0;
            int c = 0;
            for (; r < row; r++) {
                for (; c < col; c++) {
                }
            }
            if(Board[r-1][c-1] == 'o') {
                if(this.whosPlayingNow != null) {
                    this.whosPlayingNow = this.Player1;
                    this.Status = "Error: slot @ (" + row + ", " + col + ") is already occupied.";
                }
            }
            else if(Board[r-1][c-1] == 'x') {
                if(this.whosPlayingNow != null) {
                    this.whosPlayingNow = this.Player2;
                    this.Status = "Error: slot @ (" + row + ", " + col + ") is already occupied.";
                }
            }

            else{
                if(getCurrentPlayer().equals(this.Player1)) {
                    this.Board[r-1][c-1] = 'x';
                }
                else if(getCurrentPlayer().equals(this.Player2)) {
                    this.Board[r-1][c-1] = 'o';
                }
                if(this.whosPlayingNow == this.Player1) {
                    this.whosPlayingNow = this.Player2;
                    this.Status = this.whosPlayingNow + "'s turn to play...";
                }
                else if(this.whosPlayingNow == this.Player2) {
                    this.whosPlayingNow = this.Player1;
                    this.Status = this.whosPlayingNow + "'s turn to play...";
                }
            }
        }
        if(this.whosPlayingNow == null) {
            if(this.checkForTie()){
                this.Status = "Error: game is already over with a tie.";
            }
            else{
                this.Status = "Error: game is already over with a winner.";
            }
        }
        else if(this.Board[0][0] == 'x' && this.Board[1][1] == 'x' && this.Board[2][2] == 'x') {
            this.Status = "Game is over with " + this.Player1 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[0][0] == 'o' && this.Board[1][1] == 'o' && this.Board[2][2] == 'o') {
            this.Status = "Game is over with " + this.Player2 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[2][0] == 'x' && this.Board[1][1] == 'x' && this.Board[0][2] == 'x') {
            this.Status = "Game is over with " + this.Player1 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[2][0] == 'o' && this.Board[1][1] == 'o' && this.Board[0][2] == 'o') {
            this.Status = "Game is over with " + this.Player2 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[0][0] == 'x' && this.Board[0][1] == 'x' && this.Board[0][2] == 'x') {
            this.Status = "Game is over with " + this.Player1 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[0][0] == 'o' && this.Board[0][1] == 'o' && this.Board[0][2] == 'o') {
            this.Status = "Game is over with " + this.Player2 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[1][0] == 'x' && this.Board[1][1] == 'x' && this.Board[1][2] == 'x') {
            this.Status = "Game is over with " + this.Player1 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[1][0] == 'o' && this.Board[1][1] == 'o' && this.Board[1][2] == 'o') {
            this.Status = "Game is over with " + this.Player2 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[2][0] == 'x' && this.Board[2][1] == 'x' && this.Board[2][2] == 'x') {
            this.Status = "Game is over with " + this.Player1 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[2][0] == 'o' && this.Board[2][1] == 'o' && this.Board[2][2] == 'o') {
            this.Status = "Game is over with " + this.Player2 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[2][0] == 'x' && this.Board[1][0] == 'x' && this.Board[0][0] == 'x') {
            this.Status = "Game is over with " + this.Player1 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[2][0] == 'o' && this.Board[1][0] == 'o' && this.Board[0][0] == 'o') {
            this.Status = "Game is over with " + this.Player2 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[2][1] == 'x' && this.Board[1][1] == 'x' && this.Board[0][1] == 'x') {
            this.Status = "Game is over with " + this.Player1 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[2][1] == 'o' && this.Board[1][1] == 'o' && this.Board[0][1] == 'o') {
            this.Status = "Game is over with " + this.Player2 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[2][2] == 'x' && this.Board[1][2] == 'x' && this.Board[0][2] == 'x') {
            this.Status = "Game is over with " + this.Player1 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else if(this.Board[2][2] == 'o' && this.Board[1][2] == 'o' && this.Board[0][2] == 'o') {
            this.Status = "Game is over with " + this.Player2 + " being the winner.";
            this.whosPlayingNow = null;
        }
        else {
            if(this.checkForTie()){
                this.Status = "Game is over with a tie between " + this.Player1 + " and " + this.Player2 + ".";
                this.whosPlayingNow = null;
            }
        }
    }

    public String printBoard(){
        String printBoard = "";
        for(int r = 0; r < this.getBoard().length; r++){
            for(int c = 0; c < this.getBoard()[r].length; c++){
                printBoard += this.Board[r][c] + " ";
            }
            printBoard += "\n";
        }
        return printBoard;
    }

}

