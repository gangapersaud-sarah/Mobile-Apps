package eecs1022.lab7.bank.model;

public class Transaction {
    private String transaction;
    private double value;

    public Transaction(String transaction, double value){
        this.transaction = transaction;
        this.value = value;
    }

    public String getStatus(){
        String status = String.format("Transaction " + this.transaction + ": $" + "%.2f", this.value);
        return status;
    }

}
