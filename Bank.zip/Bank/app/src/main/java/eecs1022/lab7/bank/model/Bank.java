package eecs1022.lab7.bank.model;

public class Bank {

    private String Status;
    private int noc;
    Client[] clients;

    private final String[] clientStatus = new String[6];
    private int clientStatusIndex = 0;

    public Bank() {
    this.Status = "Accounts: {}";
    this.noc = 0;
    this.clients = new Client[6];
    }

        public String getStatus() {
            return Status;
        }

        public String getCorrectStatus() {
            String successString = "";
            for (int i = 0; i < clientStatusIndex - 1; i += 1) {
                successString += clientStatus[i] + ", ";
            }
            successString += clientStatus[clientStatusIndex - 1];
            return successString;
        }

        public String updateStatus(){ //updating a new balance
            String updateString = "";
            for (int i = 0; i < noc; i ++) {
                updateString += clients[i].getStatus();
                if(i != noc - 1){
                    updateString += ", ";
                }
            }

//            updateString += clients[noc - 1];
            return updateString;

        }

        public String[] getStatement(String name) {
            for (int i = 0; i < clients.length; i++) {
                if (clients[i] != null) {
                    if (clients[i].getName().equals(name)) {
                        return clients[i].getStatement();
                    }
                }
            }
            Status = "Error: From-Account " + name + " does not exist";
            return null;
        }

        public void deposit(String name, double deposit) {
            for (int i = 0; i < clients.length; i++) {
                if (clients[i] != null) {
                    if (clients[i].getName().equals(name)) {
                        if (deposit > 0) {
                            clients[i].deposit(deposit);
                            Status = String.format("Accounts: {%s}", updateStatus());
                            return;
                        } else {
                            Status = "Error: Non-Positive Amount";
                            return;
                        }
                    }
                }
            }
            Status = "Error: To-Account " + name + " does not exist";
        }

        public void withdraw(String name, double withdraw) {
            for (int i = 0; i < clients.length; i++) {
                if (clients[i] != null) {
                    if (clients[i].getName().equals(name)) {
                        if (withdraw > 0) {
                            if (withdraw <= clients[i].getBalance()) {
                                clients[i].withdraw(withdraw);
                                Status = String.format("Accounts: {%s}", updateStatus());
                                return;
                            } else {
                                Status = "Error: Amount too large to withdraw";
                                return;
                            }
                        } else {
                            Status = "Error: Non-Positive Amount";
                            return;
                        }
                    }
                }
            }
            Status = "Error: From-Account " + name + " does not exist";
        }

        public void transfer(String fromName, String toName, double transfer) {
            for (int i = 0; i < clients.length; i++) {
                if (clients[i] != null) {
                    if (clients[i].getName().equals(fromName)) {
                        for (int j = 0; j < clients.length; j++) {
                            if (clients[j] != null) {
                                if (clients[j].getName().equals(toName)) {
                                    if (transfer > 0) {
                                        if (transfer <= clients[i].getBalance()) {
                                            clients[i].withdraw(transfer);
                                            clients[j].deposit(transfer);
                                            Status = String.format("Accounts: {%s}", updateStatus());
                                            return;
                                        } else {
                                            Status = "Error: Amount too large to transfer";
                                            return;
                                        }
                                    } else {
                                        Status = "Error: Non-Positive Amount";
                                        return;
                                    }
                                }
                            }
                        }
                        Status = "Error: To-Account " + toName + " does not exist";
                        return;
                    }
                }
            }
            Status = "Error: From-Account " + fromName + " does not exist";
        }

        public void addClient(String name, double balance) {
            //clients = new Client[noc];
            if (noc < 6) {
                for (int i = 0; i < clients.length; i++) {
                    if (clients[i] != null) {
                        if (clients[i].getName().equals(name)) {
                            Status = String.format("Error: Client %s already exists", name);
                            return;
                        }
                    }
                }
                if (balance <= 0) {
                    Status = "Error: Non-Positive Initial Balance";
                } else {
                    Client currentClient = new Client(name, balance);
                    clients[noc++] = currentClient;
                    clientStatus[clientStatusIndex++] = currentClient.getStatus();
                    Status = String.format("Accounts: {%s}", getCorrectStatus());
                }
            }
            else {
                Status = "Error: Maximum Number of Accounts Reached";
            }
        }

}








