package eecs1022.lab7.bank.model;

public class Client {

        private final String Name;
        private double Amount;
        private final String[] transaction = new String[10];
        private int not = 0;

        public Client(String clientName, double moneyValue) {
            this.Name = clientName;
            this.Amount = moneyValue;
        }

        public String getStatus() {
            return String.format("%s: $%.2f", Name, Amount);
        }

        public String[] getStatement() {
            String[] TransactionResults = new String[not + 1];
            TransactionResults[0] = getStatus();
            for (int i = 1; i < TransactionResults.length; i += 1) {
                TransactionResults[i] = transaction[i - 1];
            }
            return TransactionResults;
        }

        public void deposit(double depositValue) {
            Transaction transaction = new Transaction("DEPOSIT", depositValue);
            this.Amount += depositValue;
            this.transaction[not++] = transaction.getStatus();

        }

        public void withdraw(double withdrawValue) {
            if (not < 10 && withdrawValue <= Amount) {
                Transaction transaction = new Transaction("WITHDRAW", withdrawValue);
                this.Amount -= withdrawValue;
                this.transaction[not++] = transaction.getStatus();
            }
        }

        public String getName() {
            return Name;
        }

        public double getBalance() {
            return Amount;
        }
}
